import React, {useMemo} from 'react';
import {G, P, mat, textTexture, texMat} from './parts';
import {Capy} from './Capy';
import {Mansion, Pizzaria, Castle} from './World';

/** "Vitrine da Cidade": the store items as real 3D stands (row at z = 60, x from -296 to -238.6) */
export const VX = (i: number) => -296 + i * 8.2;
export const VZ = 60;

const Price: React.FC<{text: string; y?: number}> = ({text, y = 0}) => {
  const tex = useMemo(() => texMat(textTexture(text, {bg: '#14110c', fg: '#ffd21e', border: '#ffd21e', w: 520, h: 170, size: 96})), [text]);
  return (
    <group position={[0, y, 4.1]}>
      <P geo={G.cyl} color="#3a3f47" p={[-0.9, 0.6, 0]} s={[0.05, 1.2, 0.05]} o={0} />
      <P geo={G.cyl} color="#3a3f47" p={[0.9, 0.6, 0]} s={[0.05, 1.2, 0.05]} o={0} />
      <mesh geometry={G.box} material={tex} position={[0, 1.35, 0]} scale={[2.3, 0.78, 0.08]} />
    </group>
  );
};
const Tile: React.FC<{w?: number}> = ({w = 7.4}) => <mesh geometry={G.box} material={mat('#e6dcc3')} position={[0, 0.07, 0]} scale={[w, 0.1, 8]} receiveShadow />;

export const Vitrine: React.FC<{tt: number}> = ({tt}) => {
  const sign = useMemo(() => texMat(textTexture('@seu.nome', {bg: '#ffd21e', fg: '#14110c', border: '#14110c', w: 512, h: 150, size: 84})), []);
  const board = useMemo(() => texMat(textTexture('PEDIDO NO VÍDEO', {bg: '#14110c', fg: '#ffffff', border: '#ffd21e', w: 760, h: 140, size: 76})), []);
  const flap = Math.sin(tt * 6) * 0.5;
  const clap = Math.abs(Math.sin(tt * 2.2)) * 0.5;
  return (
    <group position={[0, 0, VZ]}>
      <mesh geometry={G.box} material={mat('#a6dd6c')} position={[-267, 0.045, 0]} scale={[74, 0.04, 14]} receiveShadow />
      {/* 0: sobrado with the @ sign */}
      <group position={[VX(0), 0, 0]}>
        <Tile />
        <P geo={G.box} color="#6e7fd1" p={[0, 1.5, -0.5]} s={[3.6, 3, 2.8]} o={0.05} />
        <P geo={G.cone4} color="#2d3a8c" p={[0, 3.55, -0.5]} r={[0, Math.PI / 4, 0]} s={[3.2, 1.3, 2.4]} o={0.05} />
        <P geo={G.box} color="#5b3a1e" p={[0, 0.8, 0.92]} s={[0.8, 1.6, 0.05]} o={0.02} />
        {[-1.1, 1.1].map((x) => <P key={x} geo={G.box} color="#ffe9a8" p={[x, 1.9, 0.92]} s={[0.7, 0.7, 0.05]} o={0.02} />)}
        <mesh geometry={G.box} material={sign} position={[0, 4.75, -0.5]} scale={[2.6, 0.8, 0.12]} />
        <P geo={G.cyl} color="#3a3f47" p={[0, 4.15, -0.5]} s={[0.05, 0.7, 0.05]} o={0} />
        <Price text="R$ 9,90" />
      </group>
      {/* 1: mansion */}
      <group position={[VX(1), 0, 0]}>
        <Tile />
        <group position={[0, 0.1, -0.6]} scale={0.78}><Mansion k={1} /></group>
        <Price text="R$ 39,90" />
      </group>
      {/* 2: castle */}
      <group position={[VX(2), 0, 0]}>
        <Tile />
        <Castle t={999} tt={tt} p={[0, 0.1, -0.4]} sc={0.42} />
        <Price text="R$ 39,90" />
      </group>
      {/* 3: character podium (profession + outfit) */}
      <group position={[VX(3), 0, 0]}>
        <Tile />
        <P geo={G.cyl12} color="#ffffff" p={[0, 0.3, 0.3]} s={[3.2, 0.4, 3.2]} o={0.03} />
        <group position={[-1.6, 0.5, 0.3]}>
          <Capy scale={0.78} shirt="#1f3a7a" cap="#14234d" pose={{armL: [0, 0, 0.3], armR: [0, 0, -0.3 - Math.max(0, Math.sin(tt * 5)) * 1.8], mouth: 0.7, brow: 0.4, blink: 0, bob: Math.sin(tt * 6) * 0.04}} />
        </group>
        <group position={[0, 0.5, 0.9]}>
          <Capy scale={0.78} shirt="#ffffff" cap={null} pose={{armL: [0, 0, 0.3], armR: [0, 0, -0.3], mouth: 0.7, brow: 0.4, blink: 0, bob: Math.sin(tt * 6 + 1) * 0.04}} />
          <P geo={G.cyl12} color="#ffffff" p={[0, 1.95, 0.0]} s={[0.26, 0.5, 0.26]} o={0.02} />
        </group>
        <group position={[1.6, 0.5, 0.3]}>
          <Capy scale={0.78} shirt="#d62976" cap={null} pose={{armL: [0, 0, 0.3], armR: [0, 0, -0.3 - Math.max(0, Math.sin(tt * 5 + 2)) * 1.8], mouth: 0.7, brow: 0.4, blink: 0, bob: Math.sin(tt * 6 + 2) * 0.04}} />
          <mesh geometry={G.dome} material={mat('#e2483d')} position={[0, 1.78, 0]} scale={[0.4, 0.2, 0.4]} />
        </group>
        <Price text="R$ 19,90" />
      </group>
      {/* 4: pizzeria */}
      <group position={[VX(4), 0, 0]}>
        <Tile />
        <Pizzaria t={999} p={[0, 0.1, -0.4]} sc={1.15} />
        <Price text="R$ 29,90" />
      </group>
      {/* 5: pool */}
      <group position={[VX(5), 0, 0]}>
        <Tile />
        <P geo={G.box} color="#ffffff" p={[0, 0.2, -0.2]} s={[5.6, 0.25, 3.8]} o={0.02} />
        <mesh geometry={G.box} material={mat('#5fd9ff', {basic: true})} position={[0, 0.34, -0.2]} scale={[5.0, 0.06, 3.2]} />
        <P geo={G.cyl} color="#cfd4da" p={[-2.9, 1.1, -1.2]} s={[0.05, 2.2, 0.05]} o={0} />
        <mesh geometry={G.cone6} material={mat('#ff9d1a')} position={[-2.9, 2.35, -1.2]} scale={[1.2, 0.5, 1.2]} />
        {[1.8, 2.8].map((x) => <P key={x} geo={G.box} color="#ff7aa8" p={[x - 0.4, 0.3, 2.0]} s={[0.7, 0.12, 1.5]} o={0.02} />)}
        {Array.from({length: 5}).map((_, i) => { const ph = (tt * 0.6 + i / 5) % 1; return <mesh key={i} geometry={G.ballLo} material={mat('#ffffff', {basic: true})} position={[-1.8 + i * 0.9, 0.45 + ph * 0.7, -0.2 + Math.sin(i * 2) * 0.8]} scale={0.1 * (1 - ph)} />; })}
        <Price text="R$ 14,90" />
      </group>
      {/* 6: dragon pet */}
      <group position={[VX(6), 0, 0]}>
        <Tile />
        <P geo={G.cyl12} color="#7a8794" p={[0, 0.35, 0]} s={[2.3, 0.5, 2.3]} o={0.03} />
        <group position={[0, 1.5 + Math.sin(tt * 3) * 0.12, 0]}>
          <P geo={G.ball} color="#8e4fe0" p={[0, 0, 0]} s={[0.8, 0.6, 1.1]} o={0.04} />
          <P geo={G.ball} color="#a76bff" p={[0, 0.25, 1.0]} s={[0.45, 0.4, 0.5]} o={0.04} />
          {[-0.2, 0.2].map((x) => <P key={x} geo={G.cone4} color="#ffd21e" p={[x, 0.75, 1.0]} s={[0.07, 0.3, 0.07]} o={0} />)}
          {[-0.18, 0.18].map((x) => <mesh key={'e' + x} geometry={G.ballLo} material={mat('#4ff0ff', {basic: true})} position={[x, 0.33, 1.4]} scale={0.07} />)}
          <P geo={G.cone6} color="#8e4fe0" p={[0, -0.1, -1.2]} r={[Math.PI / 2 + 0.2, 0, 0]} s={[0.3, 1.3, 0.3]} o={0.03} />
          {[-1, 1].map((sd) => <group key={sd} rotation={[0, 0, sd * (0.4 + flap)]}><P geo={G.box} color="#d9c8ff" p={[sd * 1.3, 0.2, -0.1]} s={[2.4, 0.06, 1.4]} o={0.02} /></group>)}
        </group>
        <Price text="R$ 12,90" />
      </group>
      {/* 7: request-in-video: clapperboard + camera */}
      <group position={[VX(7), 0, 0]}>
        <Tile />
        <mesh geometry={G.box} material={board} position={[0, 4.1, -0.6]} scale={[5.6, 0.8, 0.12]} />
        <P geo={G.box} color="#14110c" p={[0, 1.6, -0.6]} s={[3.0, 2.2, 0.2]} o={0.04} />
        <mesh geometry={G.box} material={sign} position={[0, 1.55, -0.45]} scale={[2.3, 0.7, 0.06]} />
        <group position={[-1.5, 2.7, -0.5]} rotation={[0, 0, clap]}>
          <P geo={G.box} color="#14110c" p={[1.5, 0.15, 0]} s={[3.0, 0.4, 0.22]} o={0.03} />
          {[0, 1, 2, 3, 4].map((i) => <P key={i} geo={G.box} color="#ffffff" p={[0.3 + i * 0.6, 0.15, 0.12]} r={[0, 0, 0.6]} s={[0.22, 0.46, 0.04]} o={0} />)}
        </group>
        <group position={[2.4, 0, 1.6]}>
          <P geo={G.box} color="#3a3f47" p={[0, 1.4, 0]} s={[0.9, 0.7, 1.3]} o={0.04} />
          <P geo={G.cyl12} color="#14110c" p={[0, 1.4, 0.95]} r={[Math.PI / 2, 0, 0]} s={[0.3, 0.5, 0.3]} o={0.02} />
          <mesh geometry={G.ballLo} material={mat(Math.floor(tt * 2) % 2 ? '#ff3040' : '#7a2020', {basic: true})} position={[0.3, 1.8, -0.4]} scale={0.1} />
          <P geo={G.cyl} color="#3a3f47" p={[0, 0.6, 0]} s={[0.07, 1.2, 0.07]} o={0} />
        </group>
        <Price text="DE R$ 10" />
      </group>
    </group>
  );
};
