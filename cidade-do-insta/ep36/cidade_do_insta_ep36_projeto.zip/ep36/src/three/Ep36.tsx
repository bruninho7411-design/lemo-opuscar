import React, {useMemo} from 'react';
import {G, P, mat, textTexture, texMat} from './parts';
import {Girl} from './Cinema';
import {pop, clamp, easeOut} from '../timeline';

export const ZA = -95;
export const Q1 = {x: -336, T: 0.1}, Q2 = {x: -308, T: 1.5};
const hash = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

/** a castle that builds itself, then the queen appears on the balcony with her @ sign */
const BuildCastle: React.FC<{u: number; i: number; name: string; wall: string; tower: string; roof: string}> = ({u, i, name, wall, tower, roof}) => {
  const tex = useMemo(() => {
    const size = Math.max(30, Math.min(80, Math.floor(620 / (name.length * 0.5 + 2))));
    return texMat(textTexture('@' + name, {bg: '#ffd21e', fg: '#14110c', border: '#14110c', w: 640, h: 150, size}));
  }, [name]);
  if (u < 0) return null;
  const keep = easeOut(clamp(u / 0.4));
  const bounce = (k: number) => 1 + 0.18 * Math.max(0, Math.sin(clamp(k) * Math.PI));
  const towers: [number, number][] = [[-3.6, -1.6], [3.6, -1.6], [-3.6, 1.2], [3.6, 1.2]];
  return (
    <group>
      <P geo={G.box} color="#d9d2bf" p={[0, 0.1, -0.2]} s={[10.5, 0.2, 7]} o={0.02} />
      <group scale={[1, Math.max(0.001, keep), 1]}>
        <P geo={G.box} color={wall} p={[0, 2.6, -0.4]} s={[6.4, 5.2, 4.2]} o={0.05} />
      </group>
      {towers.map(([x, z], k) => {
        const h = easeOut(clamp((u - 0.15 - 0.06 * k) / 0.45));
        const rk = clamp((u - 0.5 - 0.05 * k) / 0.35);
        return (
          <group key={k} position={[x, 0, z]}>
            <group scale={[1, Math.max(0.001, h), 1]}><P geo={G.cyl12} color={tower} p={[0, 3.6, 0]} s={[1.3, 7.2, 1.3]} o={0.05} /></group>
            {h > 0.95 ? <group position={[0, 7.2 + (1 - easeOut(rk)) * 3.5, 0]} scale={[1, bounce((rk - 0.6) / 0.3), 1]}><P geo={G.cone6} color={roof} p={[0, 1.0, 0]} s={[1.9, 2.2, 1.9]} o={0.04} /></group> : null}
          </group>
        );
      })}
      {keep > 0.95 ? [-2.4, -0.8, 0.8, 2.4].map((x) => <P key={x} geo={G.box} color={wall} p={[x, 5.45, 1.6]} s={[0.9, 0.5, 0.6]} o={0.03} />) : null}
      <group scale={pop(u, 0.75, 0.3)}>
        <P geo={G.box} color="#4a2f1b" p={[0, 1.3, 1.72]} s={[1.6, 2.6, 0.1]} o={0.02} />
        <P geo={G.box} color="#cdeeff" p={[-2.0, 3.2, 1.72]} s={[0.8, 1.0, 0.08]} o={0.02} />
        <P geo={G.box} color="#cdeeff" p={[2.0, 3.2, 1.72]} s={[0.8, 1.0, 0.08]} o={0.02} />
      </group>
      {/* balcony + queen */}
      <group scale={pop(u, 0.95, 0.35)}>
        <P geo={G.box} color="#e8b923" p={[0, 4.5, 2.2]} s={[3.0, 0.2, 1.4]} o={0.03} />
        <P geo={G.box} color="#e8b923" p={[0, 5.0, 2.85]} s={[3.0, 0.7, 0.1]} o={0.02} />
        <group position={[0, 4.6, 2.2]}><Girl tt={u * 3 + i} wave={1.4} scale={1.5} dress="#ffd21e" hair="#2a1a12" /></group>
        <P geo={G.cone6} color="#ffd21e" p={[0, 7.45, 2.2]} s={[0.55, 0.45, 0.55]} o={0.03} />
        {[-0.2, 0, 0.2].map((x) => <P key={x} geo={G.cone4} color="#ffd21e" p={[x, 7.75, 2.2]} s={[0.12, 0.3, 0.12]} o={0} />)}
      </group>
      {/* flag */}
      {u > 1.0 ? (
        <group position={[0, 5.2, -1.2]} scale={pop(u, 1.0, 0.3)}>
          <P geo={G.cyl} color="#3a3f47" p={[0, 1.6, 0]} s={[0.08, 3.2, 0.08]} o={0} />
          <P geo={G.box} color="#e2483d" p={[0.7, 2.9, 0]} r={[0, Math.sin(u * 8) * 0.3, 0]} s={[1.3, 0.8, 0.05]} o={0.02} />
        </group>
      ) : null}
      {/* @ sign out front */}
      <group position={[0, 0, 4.2]} scale={pop(u, 0.85, 0.4)}>
        <P geo={G.cyl} color="#3a3f47" p={[-1.5, 0.8, 0]} s={[0.08, 1.6, 0.08]} o={0} />
        <P geo={G.cyl} color="#3a3f47" p={[1.5, 0.8, 0]} s={[0.08, 1.6, 0.08]} o={0} />
        <mesh geometry={G.box} material={tex} position={[0, 1.75, 0]} scale={[3.7, 0.95, 0.1]} />
      </group>
      {Array.from({length: 9}).map((_, k) => {
        const a = hash(i * 9 + k) * 6.28, d = clamp((u - 0.3) / 0.5);
        if (d <= 0 || d >= 1) return null;
        return <mesh key={'d' + k} geometry={G.ballLo} material={mat('#f4efe2', {basic: true})} position={[Math.cos(a) * (3.5 + 3 * d), 0.4 + d * 0.6, Math.sin(a) * (2.5 + 2.5 * d)]} scale={0.7 * (1 - d) + 0.05} />;
      })}
      {Array.from({length: 26}).map((_, k) => {
        const d = (u - 0.95) / 1.0;
        if (d <= 0 || d >= 1) return null;
        const a = hash(i * 31 + k) * 6.28, r = 1.5 + hash(i * 13 + k) * 3.5;
        return <mesh key={'c' + k} geometry={G.box} material={mat(['#ffd21e', '#ff4d6d', '#4dd0ff', '#7bdc6b', '#ffffff'][k % 5], {basic: true})} position={[Math.cos(a) * r * d * 1.6, 5 + 4 * d * (1 - d) * 3 - d * 2 * (d - 0.2), Math.sin(a) * r * d * 1.6 + 2]} rotation={[d * 9 + k, d * 7, 0]} scale={[0.22, 0.22, 0.04]} />;
      })}
    </group>
  );
};

export const Reino36: React.FC<{tt: number}> = ({tt}) => {
  const rt = tt >= 52.7 ? tt - 53.3 : tt;
  return (
    <group>
      <mesh geometry={G.box} material={mat('#a6dd6c')} position={[-322, 0.06, ZA - 2]} scale={[96, 0.06, 44]} receiveShadow />
      <mesh geometry={G.box} material={mat('#3a3f47')} position={[-322, 0.1, ZA + 12]} scale={[96, 0.06, 6]} />
      {Array.from({length: 20}).map((_, k) => <mesh key={k} geometry={G.box} material={mat('#ffd21e', {basic: true})} position={[-366 + k * 4.6, 0.15, ZA + 12]} scale={[2.2, 0.02, 0.22]} />)}
      <group position={[Q1.x, 0.1, ZA - 2]}><BuildCastle u={rt - Q1.T} i={1} name="esthergcardoso_" wall="#ffd1e6" tower="#ff9fd0" roof="#8e4fe0" /></group>
      <group position={[Q2.x, 0.1, ZA - 2]}><BuildCastle u={rt - Q2.T} i={2} name="aliciasophiapereirasimao" wall="#d9d0ff" tower="#a99bff" roof="#e2483d" /></group>
      {Array.from({length: 22}).map((_, k) => (
        <mesh key={'b' + k} geometry={G.ball} material={mat(k % 2 ? '#2f9d4a' : '#4cc765')} position={[-372 + k * 4.6, 0.5, ZA + 8.6 + hash(k) * 0.4]} scale={[0.7, 0.55, 0.7]} />
      ))}
    </group>
  );
};
