import React, {useMemo} from 'react';
import {G, P, mat, textTexture, texMat} from './parts';
import {Capy} from './Capy';
import {Mansion} from './World';
import {pop, clamp, easeOut} from '../timeline';

/** ep. 34: prize mansion (@lua_afronago) + the champion ring (@silvazx._42) */
export const MX = -262, MZ = 40;
export const AX = -292, AZ = 34;
export const T_MANS = 19.7, T_FIGHT = 29.5;

const Board: React.FC<{text: string; w: number; bg?: string; fg?: string; p: [number, number, number]; s?: number}> = ({text, w, bg = '#ffd21e', fg = '#14110c', p, s = 1}) => {
  const tex = useMemo(() => texMat(textTexture(text, {bg, fg, border: '#14110c', w: 640, h: 150, size: 80})), [text, bg, fg]);
  return <mesh geometry={G.box} material={tex} position={p} scale={[w * s, 0.9 * s, 0.12]} />;
};

export const Mansao34: React.FC<{tt: number}> = ({tt}) => {
  const k = pop(tt, T_MANS, 0.6);
  if (k <= 0.001) return null;
  return (
    <group position={[MX, 0, MZ]} scale={k}>
      <group scale={0.9}><Mansion k={1} /></group>
      <Board text="@lua_afronago" w={5.6} p={[0, 6.2, 2.6]} />
      <Board text="🏰 MANSÃO SORTEADA" w={5.6} bg="#ffffff" p={[0, 5.2, 2.6]} s={0.8} />
      {Array.from({length: 10}).map((_, i) => {
        const ph = (tt * 0.9 + i / 10) % 1;
        return <mesh key={i} geometry={G.ballLo} material={mat(['#ffd21e', '#ff4d6d', '#4dd0ff', '#7bdc6b'][i % 4], {basic: true})} position={[Math.sin(i * 2.4) * 4.5, 7.5 - ph * 7, Math.cos(i * 1.7) * 3]} scale={0.18} />;
      })}
    </group>
  );
};

export const Ringue34: React.FC<{tt: number}> = ({tt}) => {
  const k = pop(tt, T_FIGHT, 0.6);
  if (k <= 0.001) return null;
  const lt = tt - T_FIGHT;
  const pump = Math.abs(Math.sin(lt * 5)) * 0.4;
  return (
    <group position={[AX, 0, AZ]} scale={k}>
      <mesh geometry={G.box} material={mat('#a6dd6c')} position={[0, 0.04, 0]} scale={[24, 0.04, 20]} receiveShadow />
      <P geo={G.box} color="#2b2f3a" p={[0, 0.5, 0]} s={[9, 1, 9]} o={0.04} />
      <P geo={G.box} color="#c0392b" p={[0, 1.04, 0]} s={[8.6, 0.1, 8.6]} o={0.03} />
      {[[-4.1, -4.1], [4.1, -4.1], [-4.1, 4.1], [4.1, 4.1]].map(([x, z], i) => <P key={i} geo={G.cyl} color="#e8b923" p={[x, 2.1, z]} s={[0.22, 2.2, 0.22]} o={0.02} />)}
      {[1.7, 2.3, 2.9].map((y, i) => (
        <React.Fragment key={i}>
          <P geo={G.box} color={i === 1 ? '#ffffff' : '#ff4d6d'} p={[0, y, -4.1]} s={[8.2, 0.1, 0.1]} o={0.01} />
          <P geo={G.box} color={i === 1 ? '#ffffff' : '#ff4d6d'} p={[-4.1, y, 0]} s={[0.1, 0.1, 8.2]} o={0.01} />
          <P geo={G.box} color={i === 1 ? '#ffffff' : '#ff4d6d'} p={[4.1, y, 0]} s={[0.1, 0.1, 8.2]} o={0.01} />
        </React.Fragment>
      ))}
      {/* champion */}
      <group position={[0, 1.1 + Math.abs(Math.sin(lt * 5)) * 0.12, 0]}>
        <Capy scale={1.05} shirt="#c0392b" cap={null} pose={{armL: [0, 0, 2.6 + pump * 0.4], armR: [0, 0, -2.6 - pump * 0.4], mouth: 0.8, brow: 0.5, blink: 0, bob: Math.sin(lt * 6) * 0.03}} />
        <P geo={G.box} color="#e8b923" p={[0, 0.82, 0.55]} s={[1.3, 0.28, 0.2]} o={0.03} />
        <P geo={G.ball} color="#ff4d6d" p={[0, 0.82, 0.68]} s={[0.22, 0.22, 0.1]} o={0.02} />
      </group>
      <Board text="@silvazx._42" w={5.2} p={[0, 5.2, -4.1]} />
      <Board text="🥊 CAMPEÃO DA CIDADE" w={5.6} bg="#ffffff" p={[0, 4.2, -4.1]} s={0.8} />
      {/* crowd */}
      {[-9, -6.5, 6.5, 9].map((x, i) => (
        <group key={i} position={[x, 0.1 + Math.abs(Math.sin(lt * 6 + i)) * 0.35, 5.8 + (i % 2) * 1.5]}>
          <Capy scale={0.8} shirt={['#2f8f9d', '#f4c430', '#8e4fe0', '#2f9d4a'][i]} pose={{armL: [0, 0, 2.5], armR: [0, 0, -2.5], mouth: 0.8, brow: 0.4, blink: 0, bob: 0}} />
        </group>
      ))}
    </group>
  );
};
