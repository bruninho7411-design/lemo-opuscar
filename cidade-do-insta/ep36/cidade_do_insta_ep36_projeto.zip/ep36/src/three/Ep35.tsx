import React, {useMemo} from 'react';
import {G, P, mat, textTexture, texMat} from './parts';
import {Mansion} from './World';
import {Girl} from './Cinema';
import {pop, clamp, easeOut} from '../timeline';

export const MX = -262, MZ = 40;
export const AX = -292, AZ = 34;
export const T_MANS = 22.3, T_RICA = 32.4;
export const ZA = -95; // avenue street centre line (z)
export const AV_X0 = -352, AV_SPEED = 6.5;

const NAMES = ['kaian.nymellyniarnold', '_joselucas._', 'thay.fsx', 'cf_sofimeloo', 'leh22062', 'daily_da_mari_2.0', 'danillo_9921', 'jeanbatista310', 'aghatagabriellylopes', 'vitoremanuelludcke', 'ludgomessilva', 'pietro_ooliveira5'];
const WALL = ['#ffd9a0', '#bfe3ff', '#ffc2d6', '#d8f0b0', '#fff2a8', '#e3d0ff'];
const ROOF = ['#d9483b', '#2f6fd6', '#8e4fe0', '#2f9d4a', '#e8892a', '#c0392b'];
const hash = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

const Board: React.FC<{text: string; w: number; bg?: string; fg?: string; p: [number, number, number]; s?: number}> = ({text, w, bg = '#ffd21e', fg = '#14110c', p, s = 1}) => {
  const tex = useMemo(() => texMat(textTexture(text, {bg, fg, border: '#14110c', w: 640, h: 150, size: 80})), [text, bg, fg]);
  return <mesh geometry={G.box} material={tex} position={p} scale={[w * s, 0.9 * s, 0.12]} />;
};

/** a house that builds itself piece by piece, then pops its @ sign out front */
const BuildHouse: React.FC<{u: number; i: number; name: string; plaque?: boolean}> = ({u, i, name, plaque = true}) => {
  const tex = useMemo(() => {
    const size = Math.max(34, Math.min(80, Math.floor(620 / (name.length * 0.5 + 2))));
    return texMat(textTexture('@' + name, {bg: '#ffd21e', fg: '#14110c', border: '#14110c', w: 640, h: 150, size}));
  }, [name]);
  if (u < 0) return null;
  const wall = easeOut(clamp(u / 0.3));
  const roofK = clamp((u - 0.22) / 0.3);
  const roofY = (1 - easeOut(roofK)) * 3.2 + Math.max(0, Math.sin(roofK * Math.PI)) * 0.0;
  const squash = 1 + 0.18 * Math.max(0, Math.sin(clamp((u - 0.5) / 0.2) * Math.PI));
  const parts = pop(u, 0.42, 0.3);
  const sign = pop(u, 0.55, 0.4);
  const wc = WALL[i % 6], rc = ROOF[(i * 5 + 1) % 6];
  return (
    <group>
      <P geo={G.box} color="#e6dcc3" p={[0, 0.06, 0.4]} s={[4.4, 0.12, 4.4]} o={0.02} />
      <group scale={[1, Math.max(0.001, wall), 1]}>
        <P geo={G.box} color={wc} p={[0, 1.55, 0]} s={[4.0, 3.1, 3.2]} o={0.05} />
      </group>
      {wall > 0.9 ? (
        <group position={[0, 3.1 + roofY, 0]} scale={[1, squash, 1]}>
          <P geo={G.cone4} color={rc} p={[0, 1.1, 0]} r={[0, Math.PI / 4, 0]} s={[4.1, 2.2, 3.4]} o={0.05} />
        </group>
      ) : null}
      <group scale={parts}>
        <P geo={G.box} color="#6b3e1f" p={[-0.8, 0.9, 1.62]} s={[0.95, 1.8, 0.06]} o={0.02} />
        <P geo={G.box} color="#cdeeff" p={[1.0, 1.7, 1.62]} s={[1.1, 1.0, 0.06]} o={0.02} />
        <P geo={G.box} color="#ffffff" p={[1.0, 1.7, 1.59]} s={[1.25, 1.15, 0.04]} o={0.01} />
        <P geo={G.box} color="#cdeeff" p={[-1.5, 2.3, 1.62]} s={[0.5, 0.9, 0.06]} o={0.02} />
      </group>
      {/* @ sign out front */}
      <group position={[0, 0, 3.0]} scale={plaque ? sign : 0}>
        <P geo={G.cyl} color="#3a3f47" p={[-1.4, 0.8, 0]} s={[0.08, 1.6, 0.08]} o={0} />
        <P geo={G.cyl} color="#3a3f47" p={[1.4, 0.8, 0]} s={[0.08, 1.6, 0.08]} o={0} />
        <mesh geometry={G.box} material={tex} position={[0, 1.75, 0]} scale={[3.5, 0.9, 0.1]} />
      </group>
      {/* dust + confetti on landing */}
      {Array.from({length: 7}).map((_, k) => {
        const a = hash(i * 7 + k) * 6.28, d = clamp((u - 0.25) / 0.5);
        if (d <= 0 || d >= 1) return null;
        return <mesh key={'d' + k} geometry={G.ballLo} material={mat('#f4efe2', {basic: true})} position={[Math.cos(a) * (1.8 + 2.2 * d), 0.3 + d * 0.5, Math.sin(a) * (1.8 + 2.2 * d) + 0.4]} scale={0.5 * (1 - d) + 0.05} />;
      })}
      {Array.from({length: 16}).map((_, k) => {
        const d = (u - 0.5) / 0.9;
        if (d <= 0 || d >= 1) return null;
        const a = hash(i * 31 + k) * 6.28, r = 1 + hash(i * 13 + k) * 2.4;
        return <mesh key={'c' + k} geometry={G.box} material={mat(['#ffd21e', '#ff4d6d', '#4dd0ff', '#7bdc6b', '#ffffff'][k % 5], {basic: true})} position={[Math.cos(a) * r * d * 1.6, 2.2 + 2.6 * d * (1 - d) * 3 - d * 1.5 * (d - 0.2), Math.sin(a) * r * d * 1.6 + 1]} rotation={[d * 9 + k, d * 7, 0]} scale={[0.16, 0.16, 0.03]} />;
      })}
    </group>
  );
};

export const Avenida35: React.FC<{tt: number}> = ({tt}) => {
  if (tt > 9 && tt < 59.8) return null;
  const rt = tt >= 59.8 ? tt - 60.4 : tt;
  const XS = NAMES.map((_, i) => AV_X0 + 4.9 * i + 2);
  return (
    <group>
      <mesh geometry={G.box} material={mat('#a6dd6c')} position={[-322, 0.06, ZA - 2]} scale={[96, 0.06, 40]} receiveShadow />
      <mesh geometry={G.box} material={mat('#3a3f47')} position={[-322, 0.1, ZA + 5.5]} scale={[96, 0.06, 6]} />
      {Array.from({length: 20}).map((_, k) => <mesh key={k} geometry={G.box} material={mat('#ffd21e', {basic: true})} position={[-366 + k * 4.6, 0.15, ZA + 5.5]} scale={[2.2, 0.02, 0.22]} />)}
      <mesh geometry={G.box} material={mat('#d9d2bf')} position={[-322, 0.12, ZA + 1.4]} scale={[96, 0.06, 1.6]} />
      {XS.map((x, i) => {
        const T = Math.max(0.05 + 0.1 * i, (x - 9 - AV_X0) / AV_SPEED);
        return <group key={i} position={[x, 0.1, ZA - 2]}><BuildHouse u={rt - T} i={i} name={NAMES[i]} /></group>;
      })}
      {XS.map((x, i) => {
        const T = Math.max(0.2 + 0.1 * i, (x + 2.4 - 9 - AV_X0) / AV_SPEED) + 0.15;
        return <group key={'b' + i} position={[x + 2.4, 0.1, ZA - 11]} scale={0.95}><BuildHouse u={rt - T} i={i + 3} name="" plaque={false} /></group>;
      })}
      {Array.from({length: 22}).map((_, k) => (
        <mesh key={k} geometry={G.ball} material={mat(k % 2 ? '#2f9d4a' : '#4cc765')} position={[-372 + k * 4.6, 0.5, ZA + 0.9 + hash(k) * 0.4]} scale={[0.7, 0.55, 0.7]} />
      ))}
    </group>
  );
};

export const Mansao35: React.FC<{tt: number}> = ({tt}) => {
  const k = pop(tt, T_MANS, 0.6);
  if (k <= 0.001 || tt > 40) return null;
  return (
    <group position={[MX, 0, MZ]} scale={k}>
      <group scale={0.9}><Mansion k={1} /></group>
      <Board text="@stellafdrumont" w={5.6} p={[0, 6.2, 2.6]} />
      <Board text="🏰 MANSÃO SORTEADA" w={5.6} bg="#ffffff" p={[0, 5.2, 2.6]} s={0.8} />
      {Array.from({length: 10}).map((_, i) => {
        const ph = (tt * 0.9 + i / 10) % 1;
        return <mesh key={i} geometry={G.ballLo} material={mat(['#ffd21e', '#ff4d6d', '#4dd0ff', '#7bdc6b'][i % 4], {basic: true})} position={[Math.sin(i * 2.4) * 4.5, 7.5 - ph * 7, Math.cos(i * 1.7) * 3]} scale={0.18} />;
      })}
    </group>
  );
};

/** the richest woman in the city: 3-storey house with pool, gold coins, sign */
export const Rica35: React.FC<{tt: number}> = ({tt}) => {
  const k = pop(tt, T_RICA, 0.6);
  if (k <= 0.001 || tt > 45) return null;
  const lt = tt - T_RICA;
  const floors = [0, 1, 2];
  return (
    <group position={[AX, 0, AZ]} scale={k}>
      <mesh geometry={G.box} material={mat('#a6dd6c')} position={[0, 0.04, 0]} scale={[24, 0.04, 20]} receiveShadow />
      {floors.map((f) => (
        <React.Fragment key={f}>
          <P geo={G.box} color={f === 1 ? '#fff4d6' : '#ffffff'} p={[0, 1.2 + f * 2.5, -1.6]} s={[7.2 - f * 0.5, 2.4, 4.2]} o={0.05} />
          <P geo={G.box} color="#e8b923" p={[0, 2.5 + f * 2.5, -1.6]} s={[7.6 - f * 0.5, 0.16, 4.6]} o={0.03} />
          {[-2.2, 0, 2.2].map((x) => <P key={x} geo={G.box} color="#8fd3ff" p={[x, 1.3 + f * 2.5, 0.55]} s={[1.1, 1.1, 0.06]} o={0.02} />)}
        </React.Fragment>
      ))}
      <P geo={G.box} color="#6b3e1f" p={[0, 0.8, 0.56]} s={[1.0, 1.6, 0.06]} o={0.02} />
      <P geo={G.cone4} color="#c0392b" p={[0, 8.2, -1.6]} r={[0, Math.PI / 4, 0]} s={[7.2, 2.0, 4.6]} o={0.05} />
      {[-3.2, 3.2].map((x) => <P key={x} geo={G.cyl} color="#e8b923" p={[x, 3.7, 0.7]} s={[0.12, 7.2, 0.12]} o={0.02} />)}
      {/* pool */}
      <P geo={G.box} color="#ffffff" p={[-6.2, 0.16, 3.2]} s={[6.4, 0.2, 4.2]} o={0.02} />
      <mesh geometry={G.box} material={mat('#3fd0ff', {basic: true})} position={[-6.2, 0.27, 3.2]} scale={[5.8, 0.06, 3.6]} />
      {[0, 1, 2, 3, 4].map((i) => { const ph = (tt * 0.6 + i / 5) % 1; return <mesh key={i} geometry={G.ballLo} material={mat('#ffffff', {basic: true})} position={[-8 + i * 1.0, 0.4 + ph * 0.7, 3.2 + Math.sin(i * 2) * 1]} scale={0.1 * (1 - ph)} />; })}
      {/* the richest woman */}
      <group position={[3.4, 0.1, 3.6]}><Girl tt={tt} wave={1.2} scale={1.5} dress="#ffd21e" hair="#2a1a12" /></group>
      <mesh geometry={G.dome} material={mat('#ffd21e')} position={[3.4, 3.2, 3.6]} scale={[0.35, 0.18, 0.35]} />
      {/* gold coins raining */}
      {Array.from({length: 26}).map((_, i) => {
        const ph = (lt * 0.7 + hash(i)) % 1;
        return <mesh key={i} geometry={G.cyl12} material={mat('#ffd21e', {basic: true})} position={[-9 + hash(i + 5) * 18, 9 - ph * 8.8, -2 + hash(i + 11) * 8]} rotation={[lt * 6 + i, 0, 0]} scale={[0.4, 0.06, 0.4]} />;
      })}
      <Board text="@bebellaandfriends" w={6.4} p={[0, 10.6, 0.8]} s={0.9} />
      <Board text="👑 A MAIS RICA DA CIDADE" w={6.6} bg="#ffffff" p={[0, 9.6, 0.8]} s={0.75} />
    </group>
  );
};
