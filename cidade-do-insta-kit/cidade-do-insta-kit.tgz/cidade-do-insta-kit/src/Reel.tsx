import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig, getRemotionEnvironment} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {Scene} from './three/Scene';
import {shotAt, easeOut, clamp, ramp, FPS} from './timeline';
import {GameCard, GameClips, Callout} from './overlays';
import {Raffle, Rules, Counter, CourseCard, WorkersCard, Siren, GoalBar, ShopCard, Chips, PriceTag, KitCard, ProductGrid, Countdown, GiftCard, PhoneCTA} from './overlays';
import PPL from './people.json';
import {Header, Caption, FollowCard, CommentCard, LikeHeart, PollCard, FlavorCard, Confetti} from './overlays';

const PUNCH = [1.72, 3.02, 5.62, 7.46, 9.24, 10.72, 12.7, 15.44, 18.62, 22.62, 26.62, 28.12];

export const Reel: React.FC<{audio?: string}> = ({audio = 'mix11.wav'}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const t = frame / FPS;
  const s = shotAt(t);
  // zoom-in on every cut (not on the loop seam)
  const cut = s.id === 'hook' || s.id === 'loop' || s.id.startsWith('g_') ? 0 : 1 - easeOut(clamp((t - s.start) / 0.28));
  let punch = 0;
  for (const p of PUNCH) if (t >= p && t < p + 0.3) punch = Math.max(punch, 1 - easeOut((t - p) / 0.3));
  const zoom = 1 + 0.09 * cut + 0.05 * punch;
  const B0: Record<string, number> = {cta: 26.4};
  const blur = s.id in B0 ? 7 * easeOut(clamp((t - B0[s.id]) / 0.3)) : 0;
  return (
    <AbsoluteFill style={{backgroundColor: '#bfe3f4'}}>
      <AbsoluteFill style={{transform: `scale(${zoom})`, filter: blur ? `blur(${blur}px) brightness(.85)` : undefined}}>
        <ThreeCanvas width={width} height={height} shadows flat gl={{antialias: true, preserveDrawingBuffer: true}} camera={{fov: 38, position: [0, 5, 10]}}>
          <Scene t={t} />
        </ThreeCanvas>
      </AbsoluteFill>
      {/* soft vignette for text legibility */}
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,0,0,.28) 0%, rgba(0,0,0,0) 22%, rgba(0,0,0,0) 70%, rgba(0,0,0,.25) 100%)'}} />
      <GameClips t={t} clips={[
        {src: 'g_load.mp4', t0: 1.72, t1: 2.6, zoom: [1.15, 1.35]},
        {src: 'g_fly.mp4', t0: 2.6, t1: 4.88, zoom: [1.0, 1.1]},
        {src: 'g_search.mp4', t0: 4.88, t1: 8.72, from: 0.6, rate: 1.15, zoom: [1.05, 1.15]},
        {src: 'g_del.mp4', t0: 8.72, t1: 12.0, zoom: [1.0, 1.18]},
        {src: 'g_obras.mp4', t0: 12.0, t1: 14.82, zoom: [1.0, 1.15]},
        {src: 'g_outdoor.mp4', t0: 14.82, t1: 17.52, zoom: [1.05, 1.2]},
        {src: 'g_loja.mp4', t0: 17.52, t1: 23.4, rate: 0.82, zoom: [1.0, 1.12]},
      ]} />
      <Header t={t} />
      <Confetti t={t} t0={1.75} />
      <Callout t={t} t0={3.02} t1={4.88} text="💸 GRÁTIS!" top={1320} rot={-6} size={80} />
      <Callout t={t} t0={3.94} t1={4.88} text="📱 NO CELULAR" top={1480} rot={4} />
      <Callout t={t} t0={5.62} t1={8.72} text="🔍 SEU @ AQUI" top={1320} rot={-4} />
      <Callout t={t} t0={7.46} t1={8.72} text="🏠 SEU LOTE!" top={1480} rot={5} bg="#5ec26a" />
      <Callout t={t} t0={10.72} t1={12.0} text="🚨 BLITZ!" top={1400} rot={-6} size={84} bg="#ff6b6b" />
      <Callout t={t} t0={13.42} t1={14.82} text="🏗️ AO VIVO" top={1400} rot={5} />
      <Callout t={t} t0={16.02} t1={17.52} text="📢 ANUNCIE SEU @" top={1400} rot={-4} />
      <Callout t={t} t0={19.74} t1={23.4} text="🦫 COMPROU = APARECE NO MAPA" top={1500} rot={-3} size={50} bg="#5ec26a" />
      <CommentCard t={t} t0={25.3} t1={26.4} />
      <PhoneCTA t={t} t0={26.45} t1={28.66} tap={28.12} />
      <Confetti t={t} t0={28.7} />
      <Caption t={t} />
      <Audio src={staticFile(audio)} />
    </AbsoluteFill>
  );
};
